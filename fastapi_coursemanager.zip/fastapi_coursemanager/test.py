import requests

response = requests.post(
    "http://localhost:5000/api/students/1/enroll",
    json={
        "course_id": 1
    }
)

print(response.status_code)
print(response.json())