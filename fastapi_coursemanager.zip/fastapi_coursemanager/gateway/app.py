from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

@app.route(
    "/api/students/<int:id>/enroll",
    methods=["POST"]
)
def enroll(id):

    response = requests.post(
        f"http://localhost:5002/api/students/{id}/enroll",
        json=request.json
    )

    return jsonify(response.json()), response.status_code


if __name__ == "__main__":
    app.run(port=5000)