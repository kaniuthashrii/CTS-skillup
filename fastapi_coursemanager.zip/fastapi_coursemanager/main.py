from security import get_password_hash, verify_password
from schemas import UserRegister
from schemas import UserLogin
from jose import jwt
from datetime import datetime, timedelta
from fastapi import (
    FastAPI,
    HTTPException,
    status,
    BackgroundTasks,
    Response,
    Depends
)
from jose import JWTError

from fastapi.security import OAuth2PasswordBearer

from fastapi.middleware.cors import CORSMiddleware
from schemas import CourseCreate, CourseUpdate
from typing import Optional

def send_confirmation_email(student_email: str):
    print(f"Sending confirmation to {student_email}")

app = FastAPI(
    title="Course Management API",
    description="API for managing courses, students and enrollments",
    version="1.0",
    contact={
        "name": "Kaniuthashrii",
        "email": "student@example.com"
    }
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)
courses = []
users = []
SECRET_KEY = "mysecretkey"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl="/api/v1/auth/login/"
)
def get_current_user(
    token: str = Depends(oauth2_scheme)
):

    try:

        payload = jwt.decode(
            token,
            SECRET_KEY,
            algorithms=[ALGORITHM]
        )

        email = payload.get("sub")

        if email is None:

            raise HTTPException(
                status_code=401,
                detail="Invalid token"
            )

        return email

    except JWTError:

        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )
@app.get("/")
def home():
    return {"message": "API running"}


@app.post(
    "/api/v1/courses/",
    tags=["Courses"],
    summary="Create a new course",
    response_description="Returns the newly created course",
    status_code=status.HTTP_201_CREATED
)
async def create_course(
    course: CourseCreate,
    response: Response,
    current_user: str = Depends(get_current_user)
):

    new_course = {
        "id": len(courses) + 1,
        "name": course.name,
        "code": course.code,
        "credits": course.credits,
        "department_id": course.department_id
    }

    courses.append(new_course)

    response.headers["Location"] = (
        f"/api/v1/courses/{new_course['id']}"
    )

    return new_course


@app.get(
    "/api/v1/courses/",
    tags=["Courses"]
)
async def get_courses(
    page: int = 1,
    page_size: int = 2,
    search: Optional[str] = None
):

    filtered = courses

    if search:
        filtered = [
            c for c in courses
            if search.lower() in c["name"].lower()
            or search.lower() in c["code"].lower()
        ]

    total = len(filtered)

    start = (page - 1) * page_size
    end = start + page_size

    return {
        "count": total,
        "next": page + 1 if end < total else None,
        "previous": page - 1 if page > 1 else None,
        "results": filtered[start:end]
    }


@app.get(
    "/api/v1/courses/{course_id}",
    tags=["Courses"]
)
async def get_course(course_id: int):

    for course in courses:
        if course["id"] == course_id:
            return course

    raise HTTPException(
        status_code=404,
        detail="Course not found"
    )


@app.put(
    "/api/v1/courses/{course_id}",
    tags=["Courses"]
)
async def update_course(
    course_id: int,
    updated_course: CourseUpdate
):

    for course in courses:

        if course["id"] == course_id:

            if updated_course.name is not None:
                course["name"] = updated_course.name

            if updated_course.code is not None:
                course["code"] = updated_course.code

            if updated_course.credits is not None:
                course["credits"] = updated_course.credits

            if updated_course.department_id is not None:
                course["department_id"] = updated_course.department_id

            return course

    raise HTTPException(
        status_code=404,
        detail="Course not found"
    )


@app.patch(
    "/api/v1/courses/{course_id}",
    tags=["Courses"]
)
async def patch_course(
    course_id: int,
    updated_course: CourseUpdate
):

    for course in courses:

        if course["id"] == course_id:

            if updated_course.name is not None:
                course["name"] = updated_course.name

            if updated_course.code is not None:
                course["code"] = updated_course.code

            if updated_course.credits is not None:
                course["credits"] = updated_course.credits

            if updated_course.department_id is not None:
                course["department_id"] = updated_course.department_id

            return course

    raise HTTPException(
        status_code=404,
        detail="Course not found"
    )


@app.delete(
    "/api/v1/courses/{course_id}",
    tags=["Courses"],
    status_code=status.HTTP_204_NO_CONTENT
)
async def delete_course(
    course_id: int,
    current_user: str = Depends(get_current_user)
):

    for course in courses:

        if course["id"] == course_id:
            courses.remove(course)
            return

    raise HTTPException(
        status_code=404,
        detail="Course not found"
    )


@app.post(
    "/api/v1/enrollments/",
    tags=["Enrollments"]
)
async def create_enrollment(
    email: str,
    background_tasks: BackgroundTasks
):

    background_tasks.add_task(
        send_confirmation_email,
        email
    )

    return {
        "message": "Enrollment created"
    }
@app.post("/api/v1/auth/register/")
async def register(user: UserRegister):

    for existing_user in users:

        if existing_user["email"] == user.email:

            raise HTTPException(
                status_code=409,
                detail="Email already registered"
            )

    new_user = {
        "id": len(users) + 1,
        "email": user.email,

        # bcrypt is preferred because it is
        # intentionally slow and secure against
        # brute-force attacks unlike MD5/SHA256

        "hashed_password": get_password_hash(
            user.password
        ),

        "is_active": True
    }

    users.append(new_user)

    return {
        "message": "User registered successfully"
    }
@app.post("/api/v1/auth/login/")
async def login(user: UserLogin):

    for existing_user in users:

        if existing_user["email"] == user.email:

            if verify_password(
                user.password,
                existing_user["hashed_password"]
            ):

                expire = datetime.utcnow() + timedelta(
                    minutes=ACCESS_TOKEN_EXPIRE_MINUTES
                )

                token = jwt.encode(
                    {
                        "sub": user.email,
                        "exp": expire
                    },
                    SECRET_KEY,
                    algorithm=ALGORITHM
                )

                return {
                    "access_token": token,
                    "token_type": "bearer"
                }

    raise HTTPException(
        status_code=401,
        detail="Invalid credentials"
    )