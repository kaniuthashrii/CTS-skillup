| Service Name         | Responsibility         | Endpoints Owned      | Database Owned  |
| -------------------- | ---------------------- | -------------------- | --------------- |
| Student Service      | Student enrollment     | /api/students/*      | student.db      |
| Course Service       | Course management      | /api/courses/*       | course.db       |
| Auth Service         | Registration and Login | /api/auth/*          | auth.db         |
| Notification Service | Email notifications    | /api/notifications/* | notification.db |

Synchronous Communication (HTTP):

* Immediate response
* Easy to implement
* Tight coupling between services

Asynchronous Communication (Message Queue):

* Services are loosely coupled
* Better scalability
* Eventual consistency

RabbitMQ or Kafka can be used when services need reliable event-driven communication and background processing.
